//********************************************
// Student Name			:
// Student ID			:
// Student Email Address:
//********************************************
//
// Instructor: Sai-Keung WONG
// Email:	cswingo@cs.nctu.edu.tw
//			wingo.wong@gmail.com
//
// National Yang Ming Chiao Tung University, Taiwan
// Computer Science
// Date: 2021/04/
//
#include "mySystem_2048.h"
#include <iostream>
#include <cmath>
using namespace std;

static unsigned char specialKeys[] = {
    GLUT_KEY_UP,
    GLUT_KEY_DOWN,
    GLUT_KEY_LEFT,
    GLUT_KEY_RIGHT
};

int numSpecialKeys = sizeof(specialKeys)/sizeof(unsigned char);

MY_2048::MY_2048( )
{
    mNX = 4;
    mNZ = 4;
    reset( );

    mPositionX = 0;
    mPositionZ = 0;
    mFlgFocus = true;
    //
    flg_AutoPlay = false;
}

MY_2048::MY_2048( int nx, int nz )
{
    mPositionX = 0;
    mPositionZ = 0;
    mFlgFocus = true;
	flg_AutoPlay = false;
	reset( );
	mNX = nx;
    mNZ = nz;
}

void MY_2048::setDimension(int nx, int nz)
{
    mFlgFocus = true;
    mNX = nx;
    mNZ = nz;
	reset();
}


void MY_2048::setFocus( bool flg )
{
    mFlgFocus = flg;
}

void MY_2048::setPosition( int x, int z )
{
    mPositionX = x;
    mPositionZ = z;
}

//
// Copy the m's previous board 
// to the object's mBoard.
//
void MY_2048::copyPrevious( const BASE_SYSTEM *m )
{
    for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
            mBoard[j][i] = ((MY_2048*)m)->mPreviousBoard[ j ][ i ];
        }
    }
}

//
//reset the game board
//
void MY_2048::reset( )
{
    mEvent = 0;
	for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
            mBoard[j][i] = 0;
			mTmpBoard[j][i]=0;
			mPreviousBoard[j][i]=0;
        }
    }
	flg_AutoPlay = false;
}

//
// show messages and ask for input (if any)
//
void MY_2048::askForInput( )
{
    cout << "MY_2048" << endl;
    cout << "Key usage:" << endl;
    cout << "1: generate randomly the numbers 2 and 4 for all the cells" << endl;
    cout << "2: generate randomly the numbers 2, 4 and 8 for all the cells" << endl;
    cout << "3: generate randomly the numbers for all the cells" << endl;
    cout << "r: clear all the cells" << endl;
    cout << " " << endl;
    cout << "UP, DOWN, LEFT, RIGHT: move the numbers to the respective side" << endl;

}

//
// randomly generate a new number
//
void MY_2048::generateNumber( )
{
	int sign=0,sign_1=0;
    int index=rand()%2;
	int i;
	int j;
	if(index==0) index=2;
	if(index==1) index=4;
	while(true)
	{
		sign_1 = 0;
		for (int m = 0; m < mNZ; m++)
		{
			for (int n = 0; n < mNX; n++)
			{
				if (mBoard[n][m] != 0)
				{
					sign_1 ++;
				}
			}
		}
		if (sign_1 == (mNZ* mNX))
		{
			break;
		}
		i=rand()%mNX;
		j=rand()%mNZ;
		if(mBoard[i][j]==0)
		{
			mBoard[i][j]=index;
			break;
		}
		if (mBoard[i][j] != 0)
		{
			continue;
		}
	}
}

void MY_2048::moveDown( )
{
	//cout<<"down"<<endl;
    int sign=0,sign_1=0;
	for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
           mPreviousBoard[ j ][ i ]= mBoard[j][i] ;
        }
	}
	for ( int j = 0; j < mNX; ++j ) 
	{
        for ( int i =0 ; i <mNZ-1; i++ )
		{
			while(true)
			{
				sign=0;
				sign_1=0;
				if(mBoard[i][j]!=0)
				{
					for(int k=i+1;k<mNZ;k++)//merge
					{
						if(mBoard[i][j]==mBoard[k][j])
						{
							mBoard[i][j]=mBoard[i][j]*2;
							mBoard[k][j]=0;
							sign++;
							break;
						}
						else if(mBoard[k][j]==0)
						{
							continue;
						}
						break;
					}
					if(sign!=0)
					{
						break;
					}
				}
				////////////////////////////////////////////////
				if(mBoard[i+1][j]!=0 && mBoard[i+1][j]!=mBoard[i][j] && mBoard[i][j]!=0)//stay
				{
					sign++;
					break;
				}
				////////////////////////////////////////////////
				if(mBoard[i][j]==0)//get
				{
					for(int k=i+1;k<mNZ;k++)
					{
						if(mBoard[k][j]!=0)
						{
							mBoard[i][j]=mBoard[k][j];
							mBoard[k][j]=0;
							break;
						}
					}
					for(int k=i+1;k<mNZ;k++)
					{
						if(mBoard[k][j]!=0)
						{
							sign_1=1;
						}
					}
					if(sign_1)
					{
						continue;
					}
					else
					{
						break;
					}
				}
				if(mBoard[i][j]!=0)
				{
					break;
				}
				////////////////////////////////////////////////break condition
			}
		}
	}

}

void MY_2048::moveUp( )
{
	//cout<<"up"<<endl;
	int sign=0,sign_1=0;
	for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
           mPreviousBoard[ j ][ i ]= mBoard[j][i] ;
        }
	}
	for ( int j = 0; j < mNX; ++j ) 
	{
        for ( int i =mNZ-1 ; i > 0; --i )
		{
			while(true)
			{
				sign=0;
				sign_1=0;
				if(mBoard[i][j]!=0)
				{
					for(int k=i-1;k>=0;k--)//merge
					{
						if(mBoard[i][j]==mBoard[k][j])
						{
							mBoard[i][j]=mBoard[i][j]*2;
							mBoard[k][j]=0;
							sign++;
							break;
						}
						else if(mBoard[k][j]==0)
						{
							continue;
						}
						break;
					}
					if(sign!=0)
					{
						break;
					}
				}
				////////////////////////////////////////////////
				if(mBoard[i-1][j]!=0 && mBoard[i][j]!=mBoard[i-1][j] && mBoard[i][j]!=0)//stay
				{
					sign++;
					break;
				}
				////////////////////////////////////////////////
				if(mBoard[i][j]==0)//get
				{
					for(int k=i-1;k>=0;k--)
					{
						if(mBoard[k][j]!=0)
						{
							mBoard[i][j]=mBoard[k][j];
							mBoard[k][j]=0;
							sign_1=1;
							break;
						}
					}
					if(sign_1)
					{
						continue;
					}
					else
					{
						break;
					}
				}
				if(mBoard[i][j]!=0)
				{
					break;
				}
				////////////////////////////////////////////////break condition
			}
		}
	}

}

void MY_2048::moveLeft( )
{
	//cout<<"left"<<endl;
   int sign=0,sign_1=0;
	for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
           mPreviousBoard[ j ][ i ]= mBoard[j][i] ;
        }
	}
	for ( int i = 0; i < mNZ; ++i ) 
	{
        for ( int j =0 ; j <mNX-1; j++ )
		{
			while(true)
			{
				sign=0;
				sign_1=0;
				if(mBoard[i][j]!=0)
				{
					for(int k=j+1;k<mNZ;k++)//merge
					{
						if(mBoard[i][j]==mBoard[i][k])
						{
							mBoard[i][j]=mBoard[i][j]*2;
							mBoard[i][k]=0;
							sign++;
							break;
						}
						else if(mBoard[i][k]==0)
						{
							continue;
						}
						break;
					}
					if(sign!=0)
					{
						break;
					}
				}
				////////////////////////////////////////////////
				if(mBoard[i][j+1]!=0 && mBoard[i][j+1]!=mBoard[i][j] && mBoard[i][j]!=0)//stay
				{
					sign++;
					break;
				}
				////////////////////////////////////////////////
				if(mBoard[i][j]==0)//get
				{
					for(int k=j+1;k<mNZ;k++)
					{
						if(mBoard[i][k]!=0)
						{
							mBoard[i][j]=mBoard[i][k];
							mBoard[i][k]=0;
							break;
						}
					}
					for(int k=j+1;k<mNZ;k++)
					{
						if(mBoard[i][k]!=0)
						{
							sign_1=1;
						}
					}
					if(sign_1)
					{
						continue;
					}
					else
					{
						break;
					}
				}
				if(mBoard[i][j]!=0)
				{
					break;
				}
				////////////////////////////////////////////////break condition
			}
		}
	}
}

void MY_2048::moveRight( )
{
	//cout<<"right"<<endl;
    int sign=0,sign_1=0;
	for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
           mPreviousBoard[ j ][ i ]= mBoard[j][i] ;
        }
	}
	for ( int i = 0; i < mNX; ++i ) 
	{
        for ( int j =mNZ-1 ; j > 0; --j )
		{
			while(true)
			{
				sign=0;
				sign_1=0;
				if(mBoard[i][j]!=0)
				{
					for(int k=j-1;k>=0;k--)//merge
					{
						if(mBoard[i][j]==mBoard[i][k])
						{
							mBoard[i][j]=mBoard[i][j]*2;
							mBoard[i][k]=0;
							sign++;
							break;
						}
						else if(mBoard[i][k]==0)
						{
							continue;
						}
						break;
					}
					if(sign!=0)
					{
						break;
					}
				}
				////////////////////////////////////////////////
				if(mBoard[i][j-1]!=0 && mBoard[i][j-1]!=mBoard[i][j] && mBoard[i][j]!=0)//stay
				{
					sign++;
					break;
				}
				////////////////////////////////////////////////
				if(mBoard[i][j]==0)//get
				{
					for(int k=j-1;k>=0;k--)
					{
						if(mBoard[i][k]!=0)
						{
							mBoard[i][j]=mBoard[i][k];
							mBoard[i][k]=0;
							sign_1=1;
							break;
						}
					}
					if(sign_1)
					{
						continue;
					}
					else
					{
						break;
					}
				}
				if(mBoard[i][j]!=0)
				{
					break;
				}
				////////////////////////////////////////////////break condition
			}
		}
	}
}

void MY_2048::generateNumbers_All_2to4( )
{
    for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
			int index=rand()%2;
			if(index==0) index=2;
			if(index==1) index=4;
            mBoard[j][i] = index;
			mTmpBoard[j][i]=0;
			mPreviousBoard[j][i]=0;
        }
    }
}

void MY_2048::generateNumbers_All_2to8( )
{
    for ( int j = 0; j < mNZ; ++j ) {
        for ( int i = 0; i < mNX; ++i ) {
			int index=rand()%3;
			if(index==0) index=2;
			if(index==1) index=4;
			if(index==2) index=8;
            mBoard[j][i] = index;
        }
    }
}

void MY_2048::generateNumbers_All( )
{
	int sum=1;
	for ( int j = 0; j < mNZ; ++j ) 
	{
        for ( int i = 0; i < mNX; ++i ) 
		{
			int index=rand()%11;
			index=2<<(index);
            mBoard[j][i] = index;
        }
	}
}

void MY_2048::handleKeyPressedEvent( unsigned char key )
{
    switch( key ) {
    case 'r':
    case 'R':
        reset( );
        break;
    case '1':
        generateNumbers_All_2to4( );
        break;
    case '2':
        generateNumbers_All_2to8( );
        break;
    case '3':
        generateNumbers_All( );
        break;

    case 'a':
    case 'A':
		flg_AutoPlay=true;
		play_Auto();
		flg_AutoPlay=false;
        //flg_AutoPlay
        break;
    }
}

void MY_2048::performAction( unsigned char key ) {
bool flgDone = false;

    switch( key ) {
    case GLUT_KEY_UP:
        flgDone = true;
        moveUp( );
        mEvent = GLUT_KEY_UP;
        break;
    case GLUT_KEY_DOWN:
        flgDone = true;
        moveDown( );
        mEvent = GLUT_KEY_DOWN;

        break;
    case GLUT_KEY_LEFT:
        flgDone = true;
        moveLeft( );
        mEvent = GLUT_KEY_LEFT;

        break;
    case GLUT_KEY_RIGHT:
        flgDone = true;
        moveRight( );
        mEvent = GLUT_KEY_RIGHT;

        break;

    }

    if ( flgDone ) {
        generateNumber( );
    }
}

void MY_2048::handleSpecialKeyPressedEvent( unsigned char key )
{
    //
    // It takes a long time to show a message!
    //
    cout << "MY_2048::handleSpecialKeyPressedEvent:" << key << endl;
    performAction( key );
}

bool MY_2048::isAutoPlay() const
{
    return flg_AutoPlay;
}
void MY_2048::complete_copy(int src[][MAX_2048_NX], int tgt[][MAX_2048_NZ])
{
	for(int j=0;j<mNZ;j++)
	{
		for(int i=0;i<mNX;i++)
		{
			tgt[i][j]=src[i][j];
		}
	}
}
double MY_2048::ComputeScore()
{
	double score=0.0;
	pair<int,int> largest;
	double value;
	double largest_score=0.0;
	for(int j=0;j<mNZ;j++)
	{
		for(int i=0;i<mNX;i++)
		{
			double s=mBoard[j][i];
			if(s>0)
			{
				value=pow(s,0.35);
				score=score+(s*value);
			}
		}
	}
	return score;
}
double MY_2048::play_Smart_Recursive(int numSteps,unsigned char action_key,int Board[MAX_2048_NZ][MAX_2048_NX])
{
	int initBoard[MAX_2048_NZ][MAX_2048_NX];
	int sign=0;
	double tScore=0.0;
	if(numSteps<=0)
	{
		tScore=ComputeScore();
		return tScore;
	}
	performAction(action_key);
	numSteps--;
	double rate=0.85;
	double score=0.0;
	double value;
	for(int i=0;i<numSpecialKeys;i++)
	{
		complete_copy(mBoard,initBoard);
		value=pow(rate,numSteps);
		score=score*value+play_Smart_Recursive(numSteps-1,specialKeys[i],initBoard);
		complete_copy(initBoard,mBoard);
	}
	
	return score;
}
double MY_2048::play_Smart(int numForwardMoves,unsigned char action_index)
{
	double score=0.0;
	
	int initBoard[MAX_2048_NZ][MAX_2048_NX];
	complete_copy(mBoard,initBoard);//t=s,
	double fScore=play_Smart_Recursive(numForwardMoves,action_index,mBoard);
	//cout<<fScore<<endl;
	score=fScore;
	complete_copy(initBoard,mBoard);
	return score;
}
void  MY_2048::play_Auto()
{
	int initBoard;
	complete_copy(mBoard, mTmpBoard);//t=s
	double score [4];
	int level=7;
	for (int i=0;i<4;i++)
	{

		unsigned char action=specialKeys[i];
		score[i]=play_Smart(level,action);
		cout<<"----------------------------------"<<endl;
	}
	int action_index=0;
	double best_score=score[action_index];
	for(int i=1;i<numSpecialKeys;i++)
	{
		if(score[i]>best_score)
		{
			best_score=score[i];
			action_index=i;
		}
	}
	complete_copy(mTmpBoard,mBoard);
	performAction(specialKeys[action_index]);
}
//
// The update( ) function is called every frame.
//
// Design an algorithm to automatically perform
// one step.
//
void MY_2048::update( )
{
    //
    // It takes a long time to show a message!
    //
    cout << "MY_2048::update( )" << endl;
    cout << "MY_2048::flg_AutoPlay:\t" << flg_AutoPlay << endl;

    if (!flg_AutoPlay) return;
	play_Auto();
    //
    // Implement your own stuff
    //
}
