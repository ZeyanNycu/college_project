//********************************************
// Student Name			:
// Student ID			:
// Student Email Address:
//********************************************
//
// Instructor: Sai-Keung WONG
// Email:	cswingo@cs.nctu.edu.tw
//			wingo.wong@gmail.com
//
// National Yang Ming Chiao Tung University, Taiwan
// Computer Science
// Date: 2021/04/
//
#include <iostream>
#include "mySystem_GraphSystem.h"
#include <time.h>
#include <cmath>
using namespace std;

int Param::GRAPH_MAX_NUM_NODES = 1000;
int Param::GRAPH_MAX_NUM_EDGES = 1000;

GRAPH_SYSTEM::GRAPH_SYSTEM( )
{
	Param a;
	time=0;
	time_gate=1;
	//cout<<"hello"<<endl;
    mFlgAutoNodeDeletion = false;
	//cout<<"hello"<<endl;
    mNodeArr_Pool=new GRAPH_NODE[1000];
	mEdgeArr_Pool=new GRAPH_EDGE[1000];
	//cout<<a.GRAPH_MAX_NUM_EDGES<<endl;
	mCurNumOfActiveNodes = 0;
    mCurNumOfActiveEdges = 0;
	mActiveNodeArr = new int[a.GRAPH_MAX_NUM_NODES];
    mActiveEdgeArr = new int[a.GRAPH_MAX_NUM_EDGES];

	mFreeNodeArr = new int[a.GRAPH_MAX_NUM_NODES];
    mFreeEdgeArr = new int[a.GRAPH_MAX_NUM_EDGES];

	for(int i=0;i<a.GRAPH_MAX_NUM_NODES;i++)
	{
		mNodeArr_Pool[i].id=i;
		//cout<<mNodeArr_Pool[i].id<<endl;
	}
	for(int j=0;j<a.GRAPH_MAX_NUM_EDGES;j++)
	{
		mEdgeArr_Pool[j].id=j;
	}
	createDefaultGraph();
	reset();
}

void GRAPH_SYSTEM::reset( )
{
	Param a;
    stopAutoNodeDeletion();
    mPassiveSelectedNode = 0;
    mSelectedNode = 0;
    
	mCurNumOfActiveNodes = 0;
    mCurNumOfActiveEdges = 0;

	mCurNumOfFreeNodes = a.GRAPH_MAX_NUM_NODES;
    mCurNumOfFreeEdges = a.GRAPH_MAX_NUM_EDGES;

	for(int i=0;i<a.GRAPH_MAX_NUM_NODES;i++)
	{
		mFreeNodeArr[i]=i;
	}
	for(int j=0;j<a.GRAPH_MAX_NUM_EDGES;j++)
	{
		mFreeEdgeArr[j]=j;
	}
}

void GRAPH_SYSTEM::createDefaultGraph( )
{
	int id_1=0;
	int id_2=0;
    reset( );
	id_1=addNode(0,0,0,3);
	id_2=addNode(10,0,0,3);
	//cout<<"hello"<<endl;
	//cout<<id_1<<endl;
	//cout<<id_2<<endl;
	id_1=mActiveNodeArr[mCurNumOfActiveNodes-1];
	id_2=mActiveNodeArr[mCurNumOfActiveNodes-2];
	//cout<<id_1<<endl;
	//cout<<id_2<<endl;
	//cout<<mCurNumOfActiveNodes<<endl;
	//system("pause");
	addEdge(id_1,id_2);
	//cout<<"hello"<<endl;
	addNode(10,0,10,3);
	id_1=mActiveNodeArr[mCurNumOfActiveNodes-1];
	id_2=mActiveNodeArr[mCurNumOfActiveNodes-2];
	addEdge(id_1,id_2);

    //
    // Implement your own stuff
    //
}

void GRAPH_SYSTEM::createRandomGraph_DoubleCircles(int n)
{
    reset( );
	GRAPH_NODE *f;
	int id,id_1;
	int id_store[1000];
	int* bound_id_beg=id_store+(n/8);
	int *bound_id_end=id_store+(n-1)-(n/8);
	int *ans;
	double dist;
	float pi=2*3.1415926/n;
	float r_x,r_z;
    float dx = 5.0;
    float dz = 5.0;
    float r = 25; // radius
    float d = 10; // layer distance
    float offset_x = 15.;
    float offset_z = 15.;
    //
    // Implement your own stuff
    //
	for(int i=0;i<2;i++)
	{
		for(int j=0;j<n;j++)
		{
			r_x=10+(r)*cos(pi*j);
			r_z=10+(r)*sin(pi*j);
			id=addNode(r_x,0,r_z,1);
			if(i==0)
			{
				id_store[j]=id;
			}
			if(i!=0)
			{
				int a=n/4;
				int connect=rand()%a;
				ans=bound_id_end;
				for(int i=0;i<connect;i++)
				{
					ans++;
					if(ans==(id_store+(n-1)))
					{
						ans=id_store;
					}
				}
				addEdge(id,*(ans));
				bound_id_beg++;
				bound_id_end++;
				if(bound_id_beg==id_store+(n-1)) bound_id_beg=id_store;
				if(bound_id_end==id_store+(n-1)) bound_id_end=id_store;
			}
		}
		r=r-d;
	}
}

void GRAPH_SYSTEM::createNet_Circular( int n, int num_layers )
{
    reset( );
	float r_x,r_z;
	int id,pre_id,id_1;
	float pi=3.1415926;
    float dx = 5.0;
    float dz = 5.0;
    float r = 5; // radius
    float d = 5; // layer distance 
    float offset_x = 15.;
    float offset_z = 15.;
    //
    // Implement your own stuff
    //
	cout<<n<<endl;
	pi=(2*pi)/n;
	for(int i=0;i<=num_layers;i++)
	{
			for(int j=0;j<n;j++)
			{
				r_x=10+(offset_x+(d*i))*cos(pi*j);
				r_z=10+(offset_z+(d*i))*sin(pi*j);
				id=addNode(r_x,0,r_z,1);
				if(i!=num_layers)
				{
					if(j==0)	
					{
						id_1=id;
						continue;
					}
					else if (j==n-1)
					{
						addEdge(id_1,id);
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-2];
						addEdge(id,pre_id);
					}
					else
					{
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-2];
						addEdge(id,pre_id);
					}
				}
			}
			if(i!=0)
			{
				for(int k=0;k<n;k++)
				{
					id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k)];
					pre_id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k+12)];
					addEdge(id,pre_id);
				}
			}
	}
}
void GRAPH_SYSTEM::createNet_Square( int n, int num_layers )
{
    reset( );
	int id,pre_id;
	int bound;
	float dist_x=5,dist_z=5;
    float dx = 5.0;
    float dz = 5.0;
    float r = 5; // radius
    float d = 5; // layer distance 
    float offset_x = 5.;
    float offset_z = 5.;
	int error=0;
	int sign_3=0;
	cout<<n<<endl;
	cout<<num_layers<<endl;
	n=3;
	num_layers=11;
	bound=(num_layers-n)/2;
	for(int i=0;i<num_layers;i++)
	{
		int sign=0;
		dist_z=0+i*d;
		if(bound<=i && i<(bound+n))
		{
			sign=1;
		}
		for(int j=0;j<num_layers;j++)
		{
			if(sign)
			{
				int sign_2=0;
				if(bound<=j && j<(bound+n))
				{
					sign_2=1;
				}
				if(sign_2)
				{
					continue;
				}
				else
				{
					dist_x=0+j*d;
					id=addNode(dist_x,0,dist_z,1);
					if((j!=0) && j!=bound+n)
					{
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-2];
						addEdge(id,pre_id);
					}
				}
			}
			else
			{
				dist_x=0+(j*d);
				//cout<<dist_x<<endl;
				id=addNode(dist_x,0,dist_z,1);
				if(j!=0)
				{
					pre_id=mActiveNodeArr[mCurNumOfActiveNodes-2];
					addEdge(id,pre_id);
				}
			}
		}
		//cout<<id<<endl;
		if(i!=0)
		{
			cout<<sign_3<<endl;
			for(int k=0;k<num_layers;k++)
			{
				if(sign || (i==bound+n))
				{
					if(i>=bound+1 && i<bound+n || (i==(bound) && (k<bound)) || ((i==bound+n) && (k>=bound+n)))
					{
						
						id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k)];
						//cout<<"("<<id<<","<<pre_id<<")"<<endl;
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-(1+(num_layers-n)+k)];
						cout<<"("<<id<<","<<pre_id<<")"<<endl;
						addEdge(id,pre_id);
					}
					if(i==(bound) && (k>=bound) || ((i==bound+n) && (k<bound)))
					{
						id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k)];
						//cout<<"("<<id<<","<<pre_id<<")"<<endl;
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-(1+(num_layers)+k)];
						cout<<"("<<id<<","<<pre_id<<")"<<endl;
						addEdge(id,pre_id);
					}
				
					/*int sign_2=0;
					if(bound<=k && k<(bound+n))
					{
						sign_2=1;
					}
					if(sign_2 || (i==bound+n))
					{
						cout<<"hello"<<endl;
						continue;
					}
					if(sign_3==0)
					{
						id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k)];
						//cout<<"("<<id<<","<<pre_id<<")"<<endl;
						pre_id=mActiveNodeArr[mCurNumOfActiveNodes-(1+(num_layers-n)+k)];
						cout<<"("<<id<<","<<pre_id<<")"<<endl;
						addEdge(id,pre_id);
					}*/continue;
				}
				else
				{
					id=mActiveNodeArr[mCurNumOfActiveNodes-(1+k)];
					pre_id=mActiveNodeArr[mCurNumOfActiveNodes-(1+num_layers+k)];
					cout<<"("<<id<<","<<pre_id<<")"<<endl;
					addEdge(id,pre_id);
				}
			}
		}
	}
}

void GRAPH_SYSTEM::createNet_RadialCircular( int n ) {

    reset( );
	float dist_x=0;
	float dist_z=0;
    float offset_x = 15.0;
    float offset_z = 15.0;
	int id_1,id_oth;
    float r = 15; // radius
    float pi=2*3.1415926/n;
	id_1=addNode(10,0,10,1);
	for(int i=0;i<n;i++)
	{
		dist_x=0;
		dist_z=0;
		dist_x=10+offset_x*cos(pi*i);
		dist_z=10+offset_z*sin(pi*i);
		id_oth=addNode(dist_x,0,dist_z,1);
		addEdge(id_1,id_oth);
	}
}

GRAPH_NODE *GRAPH_SYSTEM::getFreeNode( )
{
	if(mCurNumOfFreeNodes==0) return 0;
	--mCurNumOfFreeNodes;
	int id = mFreeNodeArr[mCurNumOfFreeNodes];
	GRAPH_NODE *n=&mNodeArr_Pool[id];
	n->dynamicID=mCurNumOfActiveNodes;
	mActiveNodeArr[mCurNumOfActiveNodes]=n->id;
	++mCurNumOfActiveNodes;
	return n;
}
// return node id
int GRAPH_SYSTEM::addNode( float x, float y, float z, float r )
{
    GRAPH_NODE *g;
	g=getFreeNode();
	if(g==0)	return -1;//invalid id
	g->p=vector3(x,y,z);
	g->r=r;
	g->edgeID.clear();
	return g->id;
}
GRAPH_EDGE *GRAPH_SYSTEM:: getFreeEdge ( ) 
{
	if ( mCurNumOfFreeEdges == 0 ) return 0;
    --mCurNumOfFreeEdges;
    int id = mFreeEdgeArr[ mCurNumOfFreeEdges ];
    GRAPH_EDGE *e = &mEdgeArr_Pool[ id ];
    e->dynamicID = mCurNumOfActiveEdges;
	mActiveEdgeArr[mCurNumOfActiveEdges]=e->id;
    ++mCurNumOfActiveEdges;
    return e;

}
// return edge id
int GRAPH_SYSTEM::addEdge( int nodeID_0, int nodeID_1 )
{
    GRAPH_EDGE *e;
	e=getFreeEdge();
	if(e==0) return -1;
	//cout<<e->nodeID[0]<<endl;
	e->nodeID[1]=nodeID_1;
	e->nodeID[0]=nodeID_0;
	mNodeArr_Pool[ nodeID_0 ].edgeID.push_back( e->id );
    mNodeArr_Pool[ nodeID_1 ].edgeID.push_back( e->id );
    return e->id;
}

void GRAPH_SYSTEM::askForInput( )
{
    cout << "GRAPH_SYSTEM" << endl;
    cout << "Key usage:" << endl;
    cout << "1: create a default graph" << endl;
    cout << "2: create a graph with Net_Circular" << endl;
    cout << "3: create a graph with Net_Square" << endl;
    cout << "4: create a graph with Net_RadialCircular" << endl;
    cout << "5: create a graph with createRandomGraph_DoubleCircles" << endl;
    cout << "Delete: delete a node and all the edges attached at it" << endl;
    cout << "Spacebar: unselect the selected node" << endl;
    cout << " " << endl;
    cout << "Use the mouse to select nodes and add edges" << endl;
    cout << "Click the left button to select/unselect or create an edge" << endl;
    cout << " " << endl;
    cout << "A selected node is highlighted as red." << endl;
 
}

GRAPH_NODE *GRAPH_SYSTEM::findNearestNode( double x, double z, double &cur_distance2 ) const
{
    GRAPH_NODE *n = 0;
	float dist,dist_x,dist_z;
	cur_distance2=9999999;
	int index;
	int id;
	//cout<<"initial"<<"\t"<<"("<<x<<","<<z<<")"<<endl;
	if(mCurNumOfActiveNodes==0)
	{
		return n;
	}
	else
	{
		for(int i=0;i<mCurNumOfActiveNodes;i++)
		{
			dist=0;
			//cout<<"hello"<<endl;
			dist_x=0;
			dist_z=0;

			id=mActiveNodeArr[i];
			//cout<<i<<"\t"<<"("<<x<<","<<z<<")"<<endl;
			dist_x=(mNodeArr_Pool[id].p.x)-x;
			dist=pow(dist_x,2);
			dist_z=(mNodeArr_Pool[id].p.z)-z;
			dist=dist+pow(dist_z,2);
			dist=sqrt(dist);
			//cout<<dist<<endl;
			//cout<<"hello"<<endl;
			if(cur_distance2>dist)
			{
				index=i;
				cur_distance2=dist;
				//cout<<cur_distance2<<endl;
			}
		}
		//cout<<id<<endl;
		id=mActiveNodeArr[index];
		n=&mNodeArr_Pool[id];
		return n;
	}
}

//
// compute mSelectedNode
//
void GRAPH_SYSTEM::clickAt(double x, double z)
{
    //
    // Implement your own stuff
    // 
    double cur_d2;
    GRAPH_NODE *n = findNearestNode( x, z, cur_d2 );
    if ( n == 0) return;
    if ( cur_d2 > n->r*n->r || n==mSelectedNode || (n->r)<cur_d2) {
        mSelectedNode = 0;
        return;
    }
	if(mSelectedNode!=0 & mSelectedNode!=n)
	{
		addEdge(n->id,mSelectedNode->id);
		mSelectedNode=0;
		return;
	}
    mSelectedNode = n;
	//cout<<mSelectedNode->id<<endl;
    //// mSelectedNode = n;
}

void GRAPH_SYSTEM::deleteNode( int nodeID ) {
	time_gate=0;
	GRAPH_NODE node;
	int active_id=mNodeArr_Pool[nodeID].dynamicID;
	int temp_edge_id;
	int last_active_id;
	last_active_id=mActiveEdgeArr[mCurNumOfActiveNodes-1];
	if(active_id!=mCurNumOfActiveNodes-1)
	{
		mActiveNodeArr[active_id]=mActiveNodeArr[mCurNumOfActiveNodes-1];
	}
	mNodeArr_Pool[nodeID].dynamicID = 0;
	mNodeArr_Pool[mActiveNodeArr[mCurNumOfActiveNodes - 1]].dynamicID=active_id;
	mCurNumOfActiveNodes--;
	//cout<<mCurNumOfActiveNodes<<endl;
	mFreeNodeArr[mCurNumOfFreeNodes]=nodeID;
	mCurNumOfFreeNodes++;
	node=mNodeArr_Pool[nodeID];
	for(int i=0;i<node.edgeID.size();i++)
	{
		temp_edge_id=node.edgeID[i];
		//cout<<temp_edge_id<<endl;
		deleteEdge(temp_edge_id,nodeID);
	}
	time_gate=1;
}
void GRAPH_SYSTEM::deleteEdge(int ID,int nodeID)
{
	int active_edge_id=mEdgeArr_Pool[ID].dynamicID;
	GRAPH_EDGE edge;
	int connect_id_0;
	int connect_id_1;
	int last_active_id=mActiveEdgeArr[mCurNumOfActiveEdges-1];
	mActiveEdgeArr[active_edge_id]=mActiveEdgeArr[mCurNumOfActiveEdges-1];
	mEdgeArr_Pool[ID].dynamicID = 0;
	mEdgeArr_Pool[mActiveEdgeArr[mCurNumOfActiveEdges - 1]].dynamicID=active_edge_id;
	mCurNumOfActiveEdges--;
	mFreeEdgeArr[mCurNumOfFreeEdges]=ID;
	mCurNumOfFreeEdges++;
	edge=mEdgeArr_Pool[ID];
	connect_id_0=edge.nodeID[0];
	connect_id_1=edge.nodeID[1];
	if(nodeID!=connect_id_0)
	{
		for(int i=0;i<mNodeArr_Pool[connect_id_0].edgeID.size();i++)
		{
			if(mNodeArr_Pool[connect_id_0].edgeID[i]==ID)
			{
				mNodeArr_Pool[connect_id_0].edgeID.erase ((mNodeArr_Pool[connect_id_0].edgeID.begin())+i);
				break;
			}
		}
	}
	else
	{
		for(int i=0;i<mNodeArr_Pool[connect_id_1].edgeID.size();i++)
		{
			if(mNodeArr_Pool[connect_id_1].edgeID[i]==ID)
			{
				mNodeArr_Pool[connect_id_1].edgeID.erase ((mNodeArr_Pool[connect_id_1].edgeID.begin())+i);
				break;
			}
		}
	}
	time_gate=1;
}
void GRAPH_SYSTEM::deleteSelectedNode(  ) {
	 int id=mSelectedNode->id;
     deleteNode(id);
	 mSelectedNode=0;
	 mPassiveSelectedNode = 0;
}

bool GRAPH_SYSTEM::isSelectedNode( ) const
{
    
    
    if(mSelectedNode != 0)	return true;
    
    return false;
}

void GRAPH_SYSTEM::getInfoOfSelectedPoint( double &r, vector3 &p ) const
{
     r = mSelectedNode->r;
     p = mSelectedNode->p; 
}


void GRAPH_SYSTEM::handleKeyPressedEvent( unsigned char key )
{
    type=0;
    switch( key ) {
    case 127: // delete
        mFlgAutoNodeDeletion = false;
        deleteSelectedNode( );
        break;
    case '1':
		type=1;
        mFlgAutoNodeDeletion = false;
        createDefaultGraph( );
        mSelectedNode = 0;
        break;
    case '2':
		type=2;
		time=0;
        mFlgAutoNodeDeletion = false;
        createNet_Circular(12, 3);
        mSelectedNode = 0;

        break;
    case '3':
		type=3;
		time=0;
        mFlgAutoNodeDeletion = false;
        createNet_Square(5, 4); // you can modify this
        mSelectedNode = 0;

        break;
    case '4':
		time=0;
        mFlgAutoNodeDeletion = false;
        createNet_RadialCircular(24);
        mSelectedNode = 0;

        break;
    case '5':
		type=5;
		time=0;
        mFlgAutoNodeDeletion = false;
        createRandomGraph_DoubleCircles(24);
        mSelectedNode = 0;
        break;
    case 'd':
		mFlgAutoNodeDeletion = true;
		update();
        mSelectedNode = 0;
        break;
    case '<':
		int a;
		time++;
		a=24-time;
		if(24-time<=3)  a=3;
		createRandomGraph_DoubleCircles(a);
        break;
	case '>':
		int b;
		time++;
		a=24-time;
		if(24-time>=36)  b=36;
		createRandomGraph_DoubleCircles(b);
		break;
    }
}

void GRAPH_SYSTEM::handlePassiveMouseEvent( double x, double z )
{
    double cur_d2;
    GRAPH_NODE *n = findNearestNode( x, z, cur_d2 );
    if ( n == 0 ) return;
    if ( cur_d2 > n->r*n->r ) {
        mPassiveSelectedNode = 0;
        return;
    }
    mPassiveSelectedNode = n;
}

//
// get the number of nodes
//
int GRAPH_SYSTEM::getNumOfNodes( ) const
{
    return mCurNumOfActiveNodes;
}

void GRAPH_SYSTEM::getNodeInfo( int nodeIndex, double &r, vector3 &p ) const
{
	int id;
	id=mActiveNodeArr[nodeIndex];
	p=mNodeArr_Pool[id].p;
	r=mNodeArr_Pool[id].r; 
}

//
// return the number of edges
//
int GRAPH_SYSTEM::getNumOfEdges( ) const
{ 
    return mCurNumOfActiveEdges;
}

//
// an edge should have two nodes: index 0 and index 1
// return the position of node with nodeIndex
//
vector3 GRAPH_SYSTEM::getNodePositionOfEdge( int edgeIndex, int nodeIndex ) const
{
    vector3 p;
	int id;
	id=mActiveEdgeArr[edgeIndex];
	p=mNodeArr_Pool[mEdgeArr_Pool[id].nodeID[nodeIndex]].p;
	//cout<<"("<<p.x<<","<<p.y<<","<<p.z<<")"<<endl; 
    return p;
}

void GRAPH_SYSTEM::stopAutoNodeDeletion()
{
    mFlgAutoNodeDeletion = false;
}

//
// For every frame, update( ) function is called.
// 
//
void GRAPH_SYSTEM::update( )
{
	int id;
    if (!mFlgAutoNodeDeletion || mCurNumOfActiveNodes==0) {
     
        return;
    }
    mSelectedNode = 0;
    mPassiveSelectedNode = 0;
	Sleep(250);
	deleteNode(mActiveNodeArr[0]);

}